import { useState, useEffect } from 'react';  // import useEffect
import './App.css';

function App() {

    return (
        <div>     
            <h1>Contactor</h1>
        </div>
    );
}

export default App;